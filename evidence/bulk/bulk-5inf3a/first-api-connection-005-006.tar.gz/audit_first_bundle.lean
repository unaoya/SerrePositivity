import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FixedTorTotalBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineCochainModel
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineCochainMap
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.Components
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CompletionBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ResolvedScalarExtension
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ColumnPrimitive
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.LowerBound
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FixedTorBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorComponents

open Lean in
run_cmd do
  let mods : Array Name := #[`SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FixedTorTotalBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineCochainModel, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineCochainMap, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.Components, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CompletionBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ResolvedScalarExtension, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ColumnPrimitive, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.LowerBound, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FixedTorBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorComponents]
  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.modules[idx.toNat]!.module
    unless mods.contains mod do continue
    let axioms ← collectAxioms name
    unless axioms.all (#[``propext, ``Classical.choice, ``Quot.sound].contains ·) do
      throwError "HT first bundle: unexpected axioms in {name}: {axioms}"
    count := count + 1
  if count == 0 then throwError "HT first bundle: no declarations audited"
  logInfo m!"HT first bundle audit passed: {count} declarations, standard three axioms only."
