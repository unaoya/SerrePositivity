from pathlib import Path
import sys,subprocess,json,hashlib,time,re
r=Path('/Users/sugakubunka/Documents/LEAN_Projects.nosync/SerrePositivity-kerodon-layout')
w=Path('/tmp/bulk-5inf3a');tag=sys.argv[1];dry='--dry-run' in sys.argv
prefix='SerrePositivity/BhattScholze/Prismatic/HodgeTate/Comparison'
paths=set(subprocess.check_output(['git','diff','--name-only','336942ab0','--',prefix],cwd=r,text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard',prefix],cwd=r,text=True).splitlines())
mods={p[:-5].replace('/','.') :r/p for p in paths if p.endswith('.lean') and (r/p).exists()}
hashes={m:hashlib.sha256(p.read_bytes()).hexdigest() for m,p in mods.items()}
graph={m:[x for x in re.findall(r'^(?:public )?(?:meta )?import\s+(?:all\s+)?(\S+)',p.read_text(),re.M) if x in mods] for m,p in mods.items()}
previous=json.loads((r/'formalization-plans/stage-ii/bulk-5inf3a/reduced-cover-complete-tor-checkpoint.json').read_text())['source_hashes']
order=[];visiting=set();seen=set()
def visit(m):
 if m in seen:return
 if m in visiting:raise RuntimeError('cycle at '+m)
 visiting.add(m)
 for d in graph[m]:visit(d)
 visiting.remove(m);seen.add(m);order.append(m)
base='SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.'
for s in ['NativeCosimplicialHomotopyInvariance','FiniteDerivedReflection','StandardCompletedModelNaturality','StandardModelComparisonIso','RestrictedStandardComparison','CompletedRawCompatibility','RestrictedCompletedSource','RestrictedFiniteCompletionUnit','RestrictedCompletedRowsTotal','RestrictionCompletionNaturality','TensorHomComponents','CompletionAdditive','ExtensionFunctor','NaturalTruncation','TotalSplitExact']:
 if base+s in mods:visit(base+s)
for m in sorted(mods):visit(m)
def already_checked(m):
 return previous.get(m)==hashes[m] and (r/'.lake/build/lib/lean'/(m.replace('.','/')+'.olean')).exists()
if dry:
 print(json.dumps({'modules':len(mods),'unchanged_audited':sum(already_checked(m) for m in mods),'to_build':[m for m in order if not already_checked(m)]},indent=2));raise SystemExit(0)
out=w/tag;out.mkdir();(out/'source-inventory.json').write_text(json.dumps(hashes,indent=2));(out/'dependency-graph.json').write_text(json.dumps(graph,indent=2))
records={};started=time.monotonic()
for m in order:
 blocked=[d for d in graph[m] if records[d]['status'] not in ['passed','audited-unchanged']]
 rec={'module':m,'source_sha256':hashes[m]}
 if blocked:rec.update(status='blocked-by-owned-dependency',rc=None,blocked_by=blocked)
 elif already_checked(m):rec.update(status='audited-unchanged',rc=0)
 elif time.monotonic()-started>=210:rec.update(status='deferred-for-audit-reserve',rc=None)
 else:
  logname=m[len('SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.'):]+'.log'
  t=time.monotonic();print('Building',m,flush=True)
  with (out/logname).open('w') as log:
   per_target_cap=180 if m.endswith('.Universal.UniversalResolvedReflection') else 75
   target_seconds=max(1,min(per_target_cap,int(210-(time.monotonic()-started))))
   p=subprocess.run(['gtimeout','--kill-after=3s',str(target_seconds)+'s','lake','build',m+':olean'],cwd=r,stdout=log,stderr=subprocess.STDOUT)
  rec.update(status='passed' if p.returncode==0 else 'failed',rc=p.returncode,seconds=time.monotonic()-t,log=logname)
  print(m.rsplit('.',1)[1],rec['status'],flush=True)
 records[m]=rec;(out/'results.json').write_text(json.dumps(list(records.values()),indent=2))
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[m] for m,p in mods.items()),'source changed during validation'
current_paths=set(subprocess.check_output(['git','diff','--name-only','336942ab0','--',prefix],cwd=r,text=True).splitlines())
current_paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard',prefix],cwd=r,text=True).splitlines())
current_modules={p[:-5].replace('.','/') for p in current_paths if p.endswith('.lean') and (r/p).exists()}
assert current_modules=={m.replace('.','/') for m in mods},'owned module set changed during validation'
audited=[m for m in order if records[m]['status'] in ['passed','audited-unchanged']]
audit=''.join('import '+m+'\n' for m in audited)+'\nopen Lean in\nrun_cmd do\n  let mods : Array Name := #['+', '.join('`'+m for m in audited)+']\n'
audit+='''  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.modules[idx.toNat]!.module
    unless mods.contains mod do continue
    let axioms ← collectAxioms name
    unless axioms.all (#[``propext, ``Classical.choice, ``Quot.sound].contains ·) do
      throwError "HT dependency bundle: unexpected axioms in {name}: {axioms}"
    count := count + 1
  if count == 0 then throwError "HT dependency bundle: no declarations audited"
  logInfo m!"HT dependency bundle audit passed: {count} declarations, standard three axioms only."
'''
(out/'audit.lean').write_text(audit);t=time.monotonic()
with (out/'audit.log').open('w') as log:p=subprocess.run(['lake','env','lean',str(out/'audit.lean')],cwd=r,stdout=log,stderr=subprocess.STDOUT)
result={'rc':p.returncode,'seconds':time.monotonic()-t,'modules':audited,'all_prepared_modules_passed':len(audited)==len(mods),'total_prepared':len(mods),'total_elapsed_seconds':time.monotonic()-started}
(out/'audit-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
raise SystemExit(p.returncode or int(len(audited)!=len(mods)))
