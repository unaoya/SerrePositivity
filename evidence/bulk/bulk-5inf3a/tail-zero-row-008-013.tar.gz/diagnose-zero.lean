import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.Components
open CategoryTheory HomologicalComplex
open SerrePositivity.HomologicalAlgebra.CochainProductTotal
set_option pp.all true in
#check component_d_zero
set_option pp.all true in
#check Int.natCast_zero
example : ((0 : ℕ) : ℤ) = (0 : ℤ) := by rfl
