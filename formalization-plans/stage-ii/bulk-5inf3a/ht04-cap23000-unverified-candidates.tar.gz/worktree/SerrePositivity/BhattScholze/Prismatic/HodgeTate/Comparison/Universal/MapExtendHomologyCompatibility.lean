module

public import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Universal.MapExtendDegreeNormalization
public import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.CrystallineCover.HomologyCoefficientClass

/-!
# 零延長と完全な係数関手の元のホモロジー同型

## 概要
零延長と完全な係数関手を交換する二つの元のホモロジー同型は一致する。

## 方針
元の核への包含と元のホモロジー射影を使って二つの合成を比較する。

## 規約
係数関手の完全性は明示的な入力であり、一般の係数拡大に仮定しない。

## 使われ方
元の多項式作用を基底へ制限する際、元のHT全複体の標準写像を保つ。
-/

public noncomputable section
universe u
open CategoryTheory CategoryTheory.Limits HomologicalComplex
namespace SerrePositivity.BhattScholze.Prismatic.HTUniversalComparison
open HTUniversalCrystallineInput
set_option backward.isDefEq.respectTransparency false
set_option backward.isDefEq.respectTransparency.types false
variable {R S : Type u} [CommRing R] [CommRing S]

/-- 零延長と完全な係数関手の元の指定ホモロジー同型は可換。 -/
theorem mapExtendIso_homology_compatibility
    (F : ModuleCat.{u} R ⥤ ModuleCat.{u} S) [F.Additive]
    [PreservesFiniteLimits F] [PreservesFiniteColimits F]
    (K : CochainComplex (ModuleCat.{u} R) ℕ) (n : ℕ) :
    homologyMap (SerrePositivity.mapExtendIso F K ComplexShape.embeddingUpNat).hom (n : ℤ) ≫
        (((F.mapHomologicalComplex (.up ℕ)).obj K).extendHomologyIso
          ComplexShape.embeddingUpNat (j := n) rfl).hom ≫
        ((K.sc n).mapHomologyIso F).hom =
      (((K.extend ComplexShape.embeddingUpNat).sc (n : ℤ)).mapHomologyIso F).hom ≫
        F.map (K.extendHomologyIso ComplexShape.embeddingUpNat (j := n) rfl).hom := by
  let e := ComplexShape.embeddingUpNat
  let KF := (F.mapHomologicalComplex (.up ℕ)).obj K
  let X := (F.mapHomologicalComplex (.up ℤ)).obj (K.extend e)
  let Y := KF.extend e
  let g := (SerrePositivity.mapExtendIso F K e).hom
  have hF : ((K.sc n).mapCyclesIso F).hom ≫ F.map (K.iCycles n) = KF.iCycles n :=
    ShortComplex.mapCyclesIso_hom_iCycles (K.sc n) F
  have hXF : (((K.extend e).sc (n : ℤ)).mapCyclesIso F).hom ≫
      F.map ((K.extend e).iCycles (n : ℤ)) = X.iCycles (n : ℤ) :=
    ShortComplex.mapCyclesIso_hom_iCycles ((K.extend e).sc (n : ℤ)) F
  let a := cyclesMap g (n : ℤ) ≫ (KF.extendCyclesIso e (j := n) rfl).hom ≫
    ((K.sc n).mapCyclesIso F).hom
  let b := (((K.extend e).sc (n : ℤ)).mapCyclesIso F).hom ≫
    F.map (K.extendCyclesIso e (j := n) rfl).hom
  have hc : a = b := by
    apply (cancel_mono (F.map (K.iCycles n))).mp
    dsimp only [a, b]
    simp only [Category.assoc]
    rw [hF, extendCyclesIso_hom_iCycles, ← Category.assoc, cyclesMap_i,
      Category.assoc, mapExtendIso_hom_f_nat]
    rw [← F.map_comp, extendCyclesIso_hom_iCycles, F.map_comp,
      ← Category.assoc, hXF]
  apply (cancel_epi (X.homologyπ (n : ℤ))).mp
  change X.homologyπ (n : ℤ) ≫ homologyMap g (n : ℤ) ≫
      (KF.extendHomologyIso e (j := n) rfl).hom ≫ ((K.sc n).mapHomologyIso F).hom = _
  rw [← Category.assoc, ← Category.assoc, homologyπ_naturality,
    Category.assoc, Category.assoc, homologyπ_extendHomologyIso_hom,
    coefficientHomologyIso_hom_projection]
  rw [← Category.assoc (X.homologyπ (n : ℤ)), coefficientHomologyIso_hom_projection]
  rw [Category.assoc, ← F.map_comp, homologyπ_extendHomologyIso_hom, F.map_comp]
  change a ≫ F.map (K.homologyπ n) = b ≫ F.map (K.homologyπ n)
  rw [hc]

end SerrePositivity.BhattScholze.Prismatic.HTUniversalComparison
