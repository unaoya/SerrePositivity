module

public import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Universal.AffineCoverResolvedTotal
public import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CanonicalCompletedNaturality

import all SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Universal.AffineResolvedCoefficientRows

/-!
# 元のsingle行で模型を外した標準完備比較

## 概要
元の半自由行の増大を外した標準完備比較は、指定被覆の前提の下で同型。

## 方針
元のκを増大と同型な通常係数射へ分解し、同じTot増大を標準比較から外す。

## 規約
始域の選択生成元はpに制限しない。元のκと標準単位を使う。

## 使われ方
元のHT全複体の標準完備増大を検査し、ηの自然性の図式へ接続する。
-/

@[expose] public noncomputable section
set_option trace.Elab.command true
universe u
open CategoryTheory CategoryTheory.Limits AlgebraicTopology
namespace SerrePositivity.BhattScholze.Prismatic.HTUniversalComparison
open HomologicalAlgebra DifferentialGraded DerivedCompletion HTComparisonTotal HTComparisonResolution HTUniversalCrystallineInput
attribute [local instance] HasDerivedCategory.standard
set_option backward.isDefEq.respectTransparency false
set_option backward.isDefEq.respectTransparency.types false
variable {p : ℕ} [Fact p.Prime] {A B : Type u} [CommRing A] [CommRing B]
variable {P : OrientedPrism p A} {Q : OrientedPrism p B}
variable (f : OrientedPrism.Hom P Q) (hP : IsBoundedPrism P) (hQ : IsBoundedPrism Q)
variable (hg : Q.generator = (p : B)) (r : ℕ) {s : ℕ} (x : Fin s → A)
variable (hTor : ∀ n, scalarExtensionTorVanishing f.toRingHom ((affineBaseModules P hP r).obj n))
variable (hM : ∀ n : SimplexCategory, ∀ j, IsModuleComplete B (f.toRingHom (x j))
  ((affineBaseModules Q hQ r).obj n))
include hg hTor hM

/-- 元のκのTotから同型な通常係数射を外すと、元の完備した行増大のTotも擬同型。 -/
theorem affineResolvedCompletedAugmentation_total_quasiIso :
    QuasiIso ((alternatingCofaceMapComplex (Complex B) ⋙
      cochainProductTotalizationFunctor (ModuleCat.{u} B)).map
      (crystallineResolvedCompletedAugmentation f.toRingHom x
        (coefficientSingleRows (affineBaseModules P hP r)))) := by
  let T := alternatingCofaceMapComplex (Complex B) ⋙
    cochainProductTotalizationFunctor (ModuleCat.{u} B)
  let a := crystallineResolvedCompletedAugmentation f.toRingHom x
    (coefficientSingleRows (affineBaseModules P hP r))
  let b := Functor.whiskerRight (affineAnyExtendedSingleRowsMap f hP hQ r)
    (finiteCompletionFunctor (fun j => f.toRingHom (x j)))
  haveI (n : SimplexCategory) : IsIso (b.app n) := by
    haveI := affineAnyExtendedSingleRowsMap_app_isIso f hP hQ hg r n
    change IsIso ((finiteCompletionFunctor (fun j => f.toRingHom (x j))).map
      ((affineAnyExtendedSingleRowsMap f hP hQ r).app n))
    infer_instance
  haveI : IsIso b := NatIso.isIso_of_isIso_app b
  haveI : QuasiIso (T.map a ≫ T.map b) := by
    rw [← T.map_comp]
    change QuasiIso (T.map (affineResolvedCompletedRowsMap f hP hQ r x))
    exact affineResolvedCompletedRows_total_quasiIso f hP hQ hg r x hTor hM
  exact (quasiIso_iff_comp_right (T.map a) (T.map b)).mp inferInstance

omit hg hTor hM
variable (P : OrientedPrism p A) (hP : IsBoundedPrism P) (r : ℕ)

/-- 指定被覆の元のsingle行で、模型を選ばない標準完備比較自体が同型。 -/
theorem affineCoverCanonicalSingleComparison_isIso
    (hF : IsCompletelyFlat (Ideal.span {Construction61.coverModPGenerator P})
      (baseChangeScalarModule (modPMap p P.deltaStructure.frobeniusLift)))
    (hR : IsSMulRegular (A ⧸ P.ideal) (p : A ⧸ P.ideal)) :
    IsIso (canonicalCompletedBaseChangeComparison (Construction61.crystallineCoverMap P).toRingHom
      ![(p : A), P.generator]
      ((alternatingCofaceMapComplex (Complex A)).obj (affineBaseSingleRows P hP r))) := by
  let f := (Construction61.crystallineCoverMap P).toRingHom
  let x := ![(p : A), P.generator]
  let X := affineBaseSingleRows P hP r
  let E := (ModuleCat.extendScalars f).mapHomologicalComplex (.up ℤ) ⋙
    finiteCompletionFunctor (fun j => f (x j))
  let T := alternatingCofaceMapComplex (Complex (Construction61.crystallineCoverRing P)) ⋙
    cochainProductTotalizationFunctor (ModuleCat.{u} (Construction61.crystallineCoverRing P))
  haveI := affineCover_completedTotalComparison_isIso P hP r hF hR
  haveI : QuasiIso (T.map (crystallineResolvedCompletedAugmentation f x X)) :=
    affineResolvedCompletedAugmentation_total_quasiIso
      (Construction61.crystallineCoverMap P) hP (Construction61.crystallineCover_bounded P)
      (Construction61.crystallineCover_generator P) r x (affineReducedCover_scalarExtensionTorVanishing P hP r)
      (affineCoverRows_complete P r)
  haveI : IsIso (DerivedCategory.Q.map (T.map
      (crystallineResolvedCompletedAugmentation f x X))) :=
    (DerivedCategory.isIso_Q_map_iff_quasiIso _ _).mpr inferInstance
  have he := cosimplicialNativeComparison_comp_augmentation f x X 0
    (affineBaseSingleRows_lowerBound P hP r)
  haveI : IsIso (canonicalCompletedBaseChangeComparison f x
      ((alternatingCofaceMapComplex (Complex A)).obj X) ≫
      DerivedCategory.Q.map ((cochainProductTotalizationFunctor
        (ModuleCat.{u} (Construction61.crystallineCoverRing P))).map
        ((alternatingCofaceFunctorIso E).app X).hom)) := by
    rw [← he]
    infer_instance
  exact IsIso.of_isIso_comp_right _
    (DerivedCategory.Q.map ((cochainProductTotalizationFunctor
      (ModuleCat.{u} (Construction61.crystallineCoverRing P))).map
      ((alternatingCofaceFunctorIso E).app X).hom))

end SerrePositivity.BhattScholze.Prismatic.HTUniversalComparison
