from pathlib import Path
import subprocess,time,json,os
w=Path('/tmp/bulk-5inf3a');start=time.monotonic()
p=subprocess.run(['python3',str(w/'build_owned_bundle.py'),'bundle-214'])
result=w/'bundle-214/results.json'
if result.exists():
 rs=json.loads(result.read_text());rec=next((r for r in rs if r['module'].endswith('.AffineCanonicalSingleRows')),{})
 remaining=int(270-(time.monotonic()-start))
 if rec.get('rc')==124 and remaining>=25:
  seconds=min(85,remaining)
  with (w/'bundle-214/canonical-probe.log').open('w') as f:
   q=subprocess.run(['gtimeout','--kill-after=2s',str(seconds)+'s','lake','env','lean','-DmaxSynthPendingDepth=3','-DrelaxedAutoImplicit=false',str(w/'CanonicalSingleProbe214.lean')],stdout=f,stderr=subprocess.STDOUT)
  (w/'bundle-214/canonical-probe-result.json').write_text(json.dumps({'rc':q.returncode,'budget_seconds':seconds,'overall_seconds':time.monotonic()-start})+'\n')
raise SystemExit(p.returncode)
