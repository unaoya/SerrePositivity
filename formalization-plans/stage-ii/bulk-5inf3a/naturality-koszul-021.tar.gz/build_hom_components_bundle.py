from pathlib import Path
import subprocess,json,time,hashlib,sys
r=Path('/Users/sugakubunka/Documents/LEAN_Projects.nosync/SerrePositivity-kerodon-layout');w=Path('/tmp/bulk-5inf3a');tag=sys.argv[1];out=w/tag;out.mkdir();base='SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.'
allnames=['AffineCochainModel','AffineCochainMap','AffineTotalModel','Totalization.Components','Totalization.CompletionBounds','Totalization.ResolvedScalarExtension','Totalization.ColumnPrimitive','Totalization.LowerBound','Totalization.FixedTorBounds','Totalization.TensorComponents','Totalization.FixedTorTotalBounds','Totalization.TensorZeroRow','Totalization.TailBounds','Totalization.TensorAdjointComparison','Totalization.ExtensionRows','Totalization.TensorNaturalComparison','Totalization.TensorHomComponents']
names=sys.argv[2:] or ['Totalization.TensorZeroRow','Totalization.TailBounds','Totalization.TensorAdjointComparison','Totalization.ExtensionRows','Totalization.TensorNaturalComparison','Totalization.TensorHomComponents'];results=[]
mods=[base+n for n in allnames]
sourcehashes={mod:hashlib.sha256((r/(mod.replace('.','/')+'.lean')).read_bytes()).hexdigest() for mod in mods}
(out/'source-inventory.json').write_text(json.dumps(sourcehashes,indent=2))
audit=''.join('import '+m+'\n' for m in mods)+'\nopen Lean in\nrun_cmd do\n  let mods : Array Name := #['+', '.join('`'+m for m in mods)+']\n'
audit+='''  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.modules[idx.toNat]!.module
    unless mods.contains mod do continue
    let axioms ← collectAxioms name
    unless axioms.all (#[``propext, ``Classical.choice, ``Quot.sound].contains ·) do
      throwError "HT first bundle: unexpected axioms in {name}: {axioms}"
    count := count + 1
  if count == 0 then throwError "HT first bundle: no declarations audited"
  logInfo m!"HT first bundle audit passed: {count} declarations, standard three axioms only."
'''
(out/'audit.lean').write_text(audit)
for name in names:
 mod=base+name;start=time.monotonic();print('Building',mod,flush=True)
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(['lake','build',mod+':olean'],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 results.append({'module':mod,'source_sha256':sourcehashes[mod],'rc':p.returncode,'seconds':time.monotonic()-start,'log':name+'.log'});(out/'results.json').write_text(json.dumps(results,indent=2));print(name,'rc',p.returncode,flush=True)
assert all(h==hashlib.sha256((r/(m.replace('.','/')+'.lean')).read_bytes()).hexdigest() for m,h in sourcehashes.items()),'source changed'
badmods={x['module'] for x in results if x['rc']}
audited=[m for m in mods if m not in badmods]
if badmods:
 marker='  let env ← getEnv\n'
 audit=''.join('import '+m+'\n' for m in audited)+'\nopen Lean in\nrun_cmd do\n  let mods : Array Name := #['+', '.join('`'+m for m in audited)+']\n'+marker+audit.split(marker,1)[1]
 (out/'audit.lean').write_text(audit)
start=time.monotonic()
with (out/'audit.log').open('w') as log:
 p=subprocess.run(['lake','env','lean',str(out/'audit.lean')],cwd=r,stdout=log,stderr=subprocess.STDOUT)
(out/'audit-result.json').write_text(json.dumps({'rc':p.returncode,'seconds':time.monotonic()-start,'modules':audited,'partial':bool(badmods)}))
if p.returncode == 0 and tag == 'bundle-021':
 print('Audited successful first-phase modules; checking remaining independent HT02 laws within the same 280-second lease.',flush=True)
 after=subprocess.run(['python3','/tmp/bulk-5inf3a/build_total_complete_bundle.py',tag+'-follow','Totalization.TensorComparisonComponents','Totalization.CompletionAdditive','Totalization.ExtensionFunctor','Totalization.TotalCompleteness','Totalization.CompletedComparison','Totalization.NaturalTruncation','Totalization.FiniteComponents','Totalization.KoszulPowerBounds','Totalization.RowTruncationExact','Totalization.TotalSplitExact','Totalization.TensorNatComponents','Totalization.TruncationHomology','Totalization.TruncationTorBounds','Totalization.FiniteCompletion','Totalization.FiniteCompletionReflection','Totalization.FiniteTensorComparison','Totalization.KoszulScalarNaturality','Totalization.FiniteCompletionReduction','Totalization.FiniteTensorInverse','Totalization.FiniteTensorComparisonIso'],cwd=r)
 raise SystemExit(after.returncode)
raise SystemExit(p.returncode or int(bool(badmods)))
