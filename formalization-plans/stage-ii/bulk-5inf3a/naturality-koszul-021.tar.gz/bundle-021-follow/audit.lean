import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineCochainModel
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineCochainMap
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineTotalModel
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.Components
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CompletionBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ResolvedScalarExtension
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ColumnPrimitive
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.LowerBound
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FixedTorBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorComponents
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FixedTorTotalBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorZeroRow
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TailBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorAdjointComparison
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ExtensionRows
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorNaturalComparison
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorHomComponents
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorComparisonComponents
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CompletionAdditive
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ExtensionFunctor
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TotalCompleteness
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CompletedComparison
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.NaturalTruncation
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteComponents
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.KoszulPowerBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.RowTruncationExact
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TotalSplitExact
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorNatComponents
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TruncationHomology
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TruncationTorBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteCompletion
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteCompletionReflection
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteTensorComparison
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.KoszulScalarNaturality
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteCompletionReduction
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteTensorInverse
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteTensorComparisonIso

open Lean in
run_cmd do
  let mods : Array Name := #[`SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineCochainModel, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineCochainMap, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.AffineTotalModel, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.Components, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CompletionBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ResolvedScalarExtension, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ColumnPrimitive, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.LowerBound, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FixedTorBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorComponents, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FixedTorTotalBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorZeroRow, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TailBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorAdjointComparison, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ExtensionRows, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorNaturalComparison, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorHomComponents, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorComparisonComponents, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CompletionAdditive, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.ExtensionFunctor, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TotalCompleteness, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.CompletedComparison, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.NaturalTruncation, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteComponents, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.KoszulPowerBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.RowTruncationExact, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TotalSplitExact, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TensorNatComponents, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TruncationHomology, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.TruncationTorBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteCompletion, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteCompletionReflection, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteTensorComparison, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.KoszulScalarNaturality, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteCompletionReduction, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteTensorInverse, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.FiniteTensorComparisonIso]
  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.modules[idx.toNat]!.module
    unless mods.contains mod do continue
    let axioms ← collectAxioms name
    unless axioms.all (#[``propext, ``Classical.choice, ``Quot.sound].contains ·) do
      throwError "HT first bundle: unexpected axioms in {name}: {axioms}"
    count := count + 1
  if count == 0 then throwError "HT first bundle: no declarations audited"
  logInfo m!"HT first bundle audit passed: {count} declarations, standard three axioms only."
