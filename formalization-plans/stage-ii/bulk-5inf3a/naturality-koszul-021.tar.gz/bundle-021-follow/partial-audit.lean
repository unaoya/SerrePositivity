import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.KoszulPowerBounds
import SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.KoszulScalarNaturality

open Lean in
run_cmd do
  let mods : Array Name := #[`SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.KoszulPowerBounds, `SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.KoszulScalarNaturality]
  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.modules[idx.toNat]!.module
    unless mods.contains mod do continue
    let axioms ← collectAxioms name
    unless axioms.all (#[``propext, ``Classical.choice, ``Quot.sound].contains ·) do
      throwError "HT first bundle: unexpected axioms in {name}: {axioms}"
    count := count + 1
  if count == 0 then throwError "HT first bundle: no declarations audited"
  logInfo m!"HT first bundle audit passed: {count} declarations, standard three axioms only."
