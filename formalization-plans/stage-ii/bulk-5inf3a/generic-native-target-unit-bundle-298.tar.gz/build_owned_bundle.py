# Inline this helper into the final build driver so the archived driver is standalone.
def type_index_extra(r, out, audited):
 import re,json
 from pathlib import Path
 d=r/'formalization-plans/stage-ii/bulk-5inf3a'
 baseline=json.loads((d/'ht03-complete.json').read_text())['source_hashes']
 requests=[]
 pat=re.compile(r'^(?:@\[[^\n]*\]\s*)*(?:(?:private|public|protected|noncomputable)\s+)*(?:theorem|lemma|def|abbrev)\s+([^\s(:{]+)')
 for m in audited:
  path=r/(m.replace('.','/')+'.lean')
  import hashlib
  if baseline.get(m)==hashlib.sha256(path.read_bytes()).hexdigest():continue
  lines=path.read_text().splitlines()
  for n,line in enumerate(lines,1):
   match=pat.match(line)
   if match:requests.append({'module':m,'short_name':match[1].split('.')[-1],'file':str(path.relative_to(r)),'line':n,'file_lines':len(lines)})
 (out/'type-requests.json').write_text(json.dumps(requests,ensure_ascii=False,indent=2)+'\n')
 pairs=sorted({(q['module'],q['short_name']) for q in requests})
 literal=', '.join('(`'+m+', '+json.dumps(n,ensure_ascii=False)+')' for m,n in pairs)
 destination=json.dumps(str(out/'law-types.json'))
 return '''\nset_option pp.fullNames true\nset_option pp.universes true\n-- Use the supported pretty-print defaults.\nopen Lean in\nrun_cmd do\n  let env ← getEnv\n  let requests : Array (Name × String) := #['''+literal+''']\n  let mut wanted : Std.HashMap Name (Std.HashSet String) := {}\n  for (m, s) in requests do\n    wanted := wanted.insert m ((wanted[m]?.getD {}).insert s)\n  let mut rows : Array Json := #[]\n  let mut found : Std.HashSet (Name × String) := {}\n  for (name, info) in env.constants.toList do\n    let some idx := env.getModuleIdxFor? name | continue\n    let m := env.header.modules[idx.toNat]!.module\n    let some names := wanted[m]? | continue\n    let .str _ short := name | continue\n    unless names.contains short do continue\n    let rendered ← Lean.Elab.Command.liftTermElabM do\n      let fmt ← Lean.Meta.ppExpr info.type\n      pure fmt.pretty\n    let ranges ← findDeclarationRanges? name\n    let span := ranges.map fun rr => Json.mkObj [\n      ("start_line", toJson rr.range.pos.line), ("end_line", toJson rr.range.endPos.line)]\n    rows := rows.push <| Json.mkObj [("name", toJson (privateToUserName name).toString),\n      ("kernel_name", toJson name.toString), ("module", toJson m.toString),\n      ("short_name", toJson short), ("type", toJson rendered), ("range", toJson span)]\n    found := found.insert (m, short)\n  let missing := requests.filter fun r => !found.contains r\n  let result := Json.mkObj [("declarations", toJson rows),\n    ("requested", toJson requests.size), ("missing", toJson (missing.map fun (m,s) => m.toString ++ ":" ++ s))]\n  liftM <| IO.FS.writeFile '''+destination+''' (result.pretty ++ "\\n")\n  unless missing.isEmpty do throwError "law type index: {missing.size} requested declarations missing"\n  logInfo m!"HT04 law type index passed: {rows.size} declarations, missing 0."\n'''

from pathlib import Path
import sys,subprocess,json,hashlib,time,re
from functools import cache
r=Path('/Users/sugakubunka/Documents/LEAN_Projects.nosync/SerrePositivity-kerodon-layout')
w=Path('/tmp/bulk-5inf3a');tag=sys.argv[1];dry='--dry-run' in sys.argv
prefix='SerrePositivity/BhattScholze/Prismatic/HodgeTate/Comparison'
paths=set(subprocess.check_output(['git','diff','--name-only','336942ab0','--',prefix],cwd=r,text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard',prefix],cwd=r,text=True).splitlines())
mods={p[:-5].replace('/','.') :r/p for p in paths if p.endswith('.lean') and (r/p).exists()}
hashes={m:hashlib.sha256(p.read_bytes()).hexdigest() for m,p in mods.items()}
graph={m:[x for x in re.findall(r'^(?:public )?(?:meta )?import\s+(?:all\s+)?(\S+)',p.read_text(),re.M) if x in mods] for m,p in mods.items()}
previous=json.loads((r/'formalization-plans/stage-ii/bulk-5inf3a/ordinary-target-and-formal-vanishing-checkpoint.json').read_text())['source_hashes']
order=[];visiting=set();seen=set()
def visit(m):
 if m in seen:return
 if m in visiting:raise RuntimeError('cycle at '+m)
 visiting.add(m)
 for d in graph[m]:visit(d)
 visiting.remove(m);seen.add(m);order.append(m)
base='SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.Totalization.'
for s in ['NativeCosimplicialHomotopyInvariance','FiniteDerivedReflection','StandardCompletedModelNaturality','StandardModelComparisonIso','RestrictedStandardComparison','CompletedRawCompatibility','RestrictedCompletedSource','RestrictedFiniteCompletionUnit','RestrictedCompletedRowsTotal','RestrictionCompletionNaturality','TensorHomComponents','CompletionAdditive','ExtensionFunctor','NaturalTruncation','TotalSplitExact']:
 if base+s in mods:visit(base+s)
for m in sorted(mods):visit(m)
@cache
def already_checked(m):
 return previous.get(m)==hashes[m] and all(already_checked(d) for d in graph[m]) and (r/'.lake/build/lib/lean'/(m.replace('.','/')+'.olean')).exists()
if dry:
 print(json.dumps({'modules':len(mods),'unchanged_audited':sum(already_checked(m) for m in mods),'to_build':[m for m in order if not already_checked(m)]},indent=2));raise SystemExit(0)
out=w/tag;out.mkdir();(out/'source-inventory.json').write_text(json.dumps(hashes,indent=2));(out/'dependency-graph.json').write_text(json.dumps(graph,indent=2))
records={};started=time.monotonic()
for m in order:
 blocked=[d for d in graph[m] if records[d]['status'] not in ['passed','audited-unchanged']]
 rec={'module':m,'source_sha256':hashes[m]}
 if blocked:rec.update(status='blocked-by-owned-dependency',rc=None,blocked_by=blocked)
 elif already_checked(m):rec.update(status='audited-unchanged',rc=0)
 elif time.monotonic()-started>=360:rec.update(status='deferred-for-audit-reserve',rc=None)
 else:
  logname=m[len('SerrePositivity.BhattScholze.Prismatic.HodgeTate.Comparison.'):]+'.log'
  t=time.monotonic();print('Building',m,flush=True)
  with (out/logname).open('w') as log:
   per_target_cap=60 if m.endswith('.Universal.AffineCanonicalSingleRows') else 150
   target_seconds=max(1,min(per_target_cap,int(360-(time.monotonic()-started))))
   if m.endswith('.Universal.AffineOriginalCoverTargetCompatibility'):
    import signal
    path=mods[m];clean=path.read_text();phase=out/'target-phase.txt'
    probe=clean
    lines=[]
    for line in clean.splitlines():
     if re.match(r'^  (?:let|have|apply|calc)\b',line):
      marker=json.dumps(line[:150]+'\n',ensure_ascii=False)
      lines.append('  run_tac do liftM <| IO.FS.writeFile '+json.dumps(str(phase))+' '+marker)
     lines.append(line)
    probe='\n'.join(lines)+'\n';(out/'target-probe.lean.txt').write_text(probe)
    def terminate_probe(sig,frame):raise SystemExit(143)
    old_handler=signal.signal(signal.SIGTERM,terminate_probe)
    try:
     path.write_text(probe)
     p=subprocess.run(['gtimeout','--kill-after=3s','90s','lake','build',m+':olean'],cwd=r,stdout=log,stderr=subprocess.STDOUT)
    finally:
     path.write_text(clean);signal.signal(signal.SIGTERM,old_handler)
    if p.returncode==0:
     p=subprocess.run(['gtimeout','--kill-after=3s',str(target_seconds)+'s','lake','build',m+':olean'],cwd=r,stdout=log,stderr=subprocess.STDOUT)
   else:
    p=subprocess.run(['gtimeout','--kill-after=3s',str(target_seconds)+'s','lake','build',m+':olean'],cwd=r,stdout=log,stderr=subprocess.STDOUT)
  rec.update(status='passed' if p.returncode==0 else 'failed',rc=p.returncode,seconds=time.monotonic()-t,log=logname)
  print(m.rsplit('.',1)[1],rec['status'],flush=True)
 records[m]=rec;(out/'results.json').write_text(json.dumps(list(records.values()),indent=2))
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[m] for m,p in mods.items()),'source changed during validation'
current_paths=set(subprocess.check_output(['git','diff','--name-only','336942ab0','--',prefix],cwd=r,text=True).splitlines())
current_paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard',prefix],cwd=r,text=True).splitlines())
current_modules={p[:-5].replace('.','/') for p in current_paths if p.endswith('.lean') and (r/p).exists()}
assert current_modules=={m.replace('.','/') for m in mods},'owned module set changed during validation'
audited=[m for m in order if records[m]['status'] in ['passed','audited-unchanged']]
audit=''.join('import '+m+'\n' for m in audited)+'\nopen Lean in\nrun_cmd do\n  let mods : Array Name := #['+', '.join('`'+m for m in audited)+']\n'
audit+='''  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.modules[idx.toNat]!.module
    unless mods.contains mod do continue
    let axioms ← collectAxioms name
    unless axioms.all (#[``propext, ``Classical.choice, ``Quot.sound].contains ·) do
      throwError "HT dependency bundle: unexpected axioms in {name}: {axioms}"
    count := count + 1
  if count == 0 then throwError "HT dependency bundle: no declarations audited"
  logInfo m!"HT dependency bundle audit passed: {count} declarations, standard three axioms only."
'''
if '--types' in sys.argv:
 audit='import Lean\n'+audit+type_index_extra(r,out,audited)
(out/'audit.lean').write_text(audit);t=time.monotonic()
with (out/'audit.log').open('w') as log:p=subprocess.run(['lake','env','lean',str(out/'audit.lean')],cwd=r,stdout=log,stderr=subprocess.STDOUT)
result={'rc':p.returncode,'seconds':time.monotonic()-t,'modules':audited,'all_prepared_modules_passed':len(audited)==len(mods),'total_prepared':len(mods),'total_elapsed_seconds':time.monotonic()-started}
(out/'audit-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
raise SystemExit(p.returncode or int(len(audited)!=len(mods)))
