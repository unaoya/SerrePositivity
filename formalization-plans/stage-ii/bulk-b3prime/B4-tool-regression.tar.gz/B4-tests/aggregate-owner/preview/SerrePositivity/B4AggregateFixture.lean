module
public import SerrePositivity.BhattScholze.Perfectoidization.Interface.TheoryInterface
public import SerrePositivity.EInfinity

/-! Ω: public aggregate no longer exports the BS interface. -/
#check SerrePositivity.EInfinity.Perfectoidization.IsTheoryDiscrete
